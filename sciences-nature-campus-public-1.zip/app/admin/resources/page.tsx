import {getSession} from "@/lib/auth";
import {prisma} from "@/lib/prisma";
import Link from "next/link";
import DeleteResourceButton from "./delete-resource-button";

export default async function AdminResources(){
  const s=await getSession();
  const u=s?await prisma.user.findUnique({where:{id:s.id}}):null;
  if(!u||u.role!=="ADMIN") return <main className="container"><section className="section"><h1>Administration</h1><p>Accès réservé aux administrateurs.</p><Link className="btn" href="/login">Connexion</Link></section></main>;

  const resources=await prisma.resource.findMany({include:{subject:true},orderBy:{createdAt:"desc"}});

  return <main className="container"><section className="section">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
      <h1>Ressources</h1>
      <Link className="btn" href="/admin/upload">Ajouter une ressource</Link>
    </div>
    <p className="muted">{resources.length} ressource{resources.length>1?"s":""} au total.</p>
    <table className="table">
      <thead><tr><th>Titre</th><th>Niveau</th><th>Matière</th><th>Type</th><th>PDF</th><th>IA</th><th></th></tr></thead>
      <tbody>
        {resources.map(r=><tr key={r.id}>
          <td>{r.title}</td>
          <td><span className="badge">{r.level}</span></td>
          <td>{r.subject.name}</td>
          <td>{r.type}</td>
          <td>{r.fileUrl?<a href={r.fileUrl} download>Télécharger</a>:<span className="muted">—</span>}</td>
          <td>{r.openaiFileId?"Indexée":<span className="muted">Non</span>}</td>
          <td><DeleteResourceButton id={r.id} title={r.title}/></td>
        </tr>)}
        {resources.length===0&&<tr><td colSpan={7} className="muted">Aucune ressource pour le moment.</td></tr>}
      </tbody>
    </table>
  </section></main>;
}

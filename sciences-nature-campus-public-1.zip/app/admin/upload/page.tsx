"use client";
import {useEffect,useState} from "react";
import Link from "next/link";

export default function Upload(){
  const [level,setLevel]=useState("L1");
  const [subjects,setSubjects]=useState<{id:string;name:string}[]>([]);
  const [msg,setMsg]=useState("");
  const [busy,setBusy]=useState(false);

  useEffect(()=>{
    fetch(`/api/subjects?level=${level}`).then(r=>r.json()).then(setSubjects);
  },[level]);

  async function go(e:any){
    e.preventDefault();
    setBusy(true);
    setMsg("");
    try{
      const d=new FormData(e.currentTarget);
      const r=await fetch("/api/resources",{method:"POST",body:d});
      const x=await r.json();
      setMsg(x.message||x.error||"Terminé");
      if(r.ok) e.currentTarget.reset();
    }finally{setBusy(false)}
  }

  return <main className="container">
    <form className="form card" onSubmit={go}>
      <h1>Ajouter un document</h1>
      <p className="muted">PDF ≤ 20 Mo. Le document sera automatiquement envoyé à la base de connaissances IA de son niveau.</p>
      <label>Titre</label>
      <input name="title" placeholder="Titre" required/>
      <label>Description</label>
      <textarea name="description" placeholder="Description"/>
      <label>Niveau</label>
      <select name="level" value={level} onChange={e=>setLevel(e.target.value)}>
        <option value="L1">L1</option>
        <option value="L2">L2</option>
      </select>
      <label>Type</label>
      <select name="type" defaultValue="COURSE">
        <option>COURSE</option>
        <option>TD</option>
        <option>TP</option>
        <option>EXERCISE</option>
        <option>CORRECTION</option>
      </select>
      <label>Matière</label>
      <input name="subject" placeholder="Nom de la matière" list="subject-list" required/>
      <datalist id="subject-list">
        {subjects.map(s=><option value={s.name} key={s.id}/>)}
      </datalist>
      <p className="muted" style={{marginTop:-8}}>Réutilise un nom existant pour éviter de dupliquer une matière : {subjects.map(s=>s.name).join(", ")||"aucune matière pour ce niveau pour l'instant"}.</p>
      <label>Fichier PDF</label>
      <input name="file" type="file" accept=".pdf"/>
      <button className="btn" disabled={busy}>{busy?"Envoi…":"Enregistrer"}</button>
      {msg&&<p>{msg}</p>}
    </form>
    <p className="container"><Link className="btn secondary" href="/admin/resources">Voir toutes les ressources</Link></p>
  </main>;
}

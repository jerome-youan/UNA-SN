import {getSession} from "@/lib/auth";
import {prisma} from "@/lib/prisma";
import Link from "next/link";
import DeleteQuizButton from "./delete-quiz-button";

export default async function AdminQuizzes(){
  const s=await getSession();
  const u=s?await prisma.user.findUnique({where:{id:s.id}}):null;
  if(!u||u.role!=="ADMIN") return <main className="container"><section className="section"><h1>Administration</h1><p>Accès réservé aux administrateurs.</p><Link className="btn" href="/login">Connexion</Link></section></main>;

  const quizzes=await prisma.quiz.findMany({
    include:{subject:true,questions:true,_count:{select:{attempts:true}}},
    orderBy:{createdAt:"desc"}
  });

  return <main className="container"><section className="section">
    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",flexWrap:"wrap",gap:12}}>
      <h1>Quiz</h1>
      <Link className="btn" href="/admin/quizzes/new">Créer un quiz</Link>
    </div>
    <p className="muted">{quizzes.length} quiz{quizzes.length>1?"z":""} au total.</p>
    <table className="table">
      <thead><tr><th>Titre</th><th>Niveau</th><th>Matière</th><th>Questions</th><th>Tentatives</th><th></th></tr></thead>
      <tbody>
        {quizzes.map(q=><tr key={q.id}>
          <td>{q.title}</td>
          <td><span className="badge">{q.level}</span></td>
          <td>{q.subject.name}</td>
          <td>{q.questions.length}</td>
          <td>{q._count.attempts}</td>
          <td><DeleteQuizButton id={q.id} title={q.title}/></td>
        </tr>)}
        {quizzes.length===0&&<tr><td colSpan={6} className="muted">Aucun quiz pour le moment.</td></tr>}
      </tbody>
    </table>
  </section></main>;
}

import {getSession} from "@/lib/auth";
import {prisma} from "@/lib/prisma";
import Link from "next/link";
import QuizForm from "./quiz-form";

export default async function NewQuiz(){
  const s=await getSession();
  const u=s?await prisma.user.findUnique({where:{id:s.id}}):null;
  if(!u||u.role!=="ADMIN") return <main className="container"><section className="section"><h1>Administration</h1><p>Accès réservé aux administrateurs.</p><Link className="btn" href="/login">Connexion</Link></section></main>;

  const subjects=await prisma.subject.findMany({orderBy:{name:"asc"}});

  return <main className="container"><section className="section">
    <h1>Créer un quiz</h1>
    <p className="muted">Ajoute des questions à choix multiples. La bonne réponse et une explication optionnelle seront montrées après la correction.</p>
    <QuizForm subjects={subjects.map(s=>({id:s.id,name:s.name,level:s.level}))}/>
  </section></main>;
}

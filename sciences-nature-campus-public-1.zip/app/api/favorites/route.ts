import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";

export async function POST(req:Request){
  const s=await getSession();
  if(!s) return NextResponse.json({error:"Connectez-vous pour ajouter un favori."},{status:401});

  const {resourceId}=await req.json();
  if(!resourceId) return NextResponse.json({error:"Ressource manquante."},{status:400});

  const resource=await prisma.resource.findUnique({where:{id:resourceId}});
  if(!resource) return NextResponse.json({error:"Ressource introuvable."},{status:404});

  const existing=await prisma.favorite.findUnique({where:{userId_resourceId:{userId:s.id,resourceId}}});
  if(existing){
    await prisma.favorite.delete({where:{id:existing.id}});
    return NextResponse.json({favorited:false});
  }
  await prisma.favorite.create({data:{userId:s.id,resourceId}});
  return NextResponse.json({favorited:true});
}

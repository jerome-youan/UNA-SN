import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";
import fs from "fs/promises";
import path from "path";
import {getOrCreateVectorStore,uploadPdfToVectorStore} from "@/lib/openai-files";

export async function POST(req:Request){
  const s=await getSession();
  if(!s)return NextResponse.json({error:"Non authentifié."},{status:401});
  const u=await prisma.user.findUnique({where:{id:s.id}});
  if(!u||u.role!=="ADMIN")return NextResponse.json({error:"Accès interdit."},{status:403});

  const form=await req.formData();
  const title=String(form.get("title")||"");
  const description=String(form.get("description")||"");
  const level=String(form.get("level")||"L1") as "L1"|"L2";
  const type=String(form.get("type")||"COURSE") as any;
  const subjectName=String(form.get("subject")||"");
  const file=form.get("file");

  if(!title||!subjectName)return NextResponse.json({error:"Titre et matière requis."},{status:400});
  if(level!=="L1"&&level!=="L2")return NextResponse.json({error:"Niveau invalide."},{status:400});

  const subject=await prisma.subject.upsert({
    where:{id:`${level}-${subjectName}`},
    update:{},
    create:{id:`${level}-${subjectName}`,name:subjectName,level}
  });

  let fileUrl:string|null=null;
  let openaiFileId:string|null=null;

  if(file instanceof File && file.size){
    if(file.type!=="application/pdf") return NextResponse.json({error:"Seuls les PDF sont acceptés."},{status:400});
    if(file.size>20*1024*1024) return NextResponse.json({error:"PDF limité à 20 Mo."},{status:400});

    const safe=file.name.replace(/[^a-zA-Z0-9._-]/g,"_");
    const stored=`${Date.now()}-${safe}`;
    const localPath=path.join(process.cwd(),"public/uploads",stored);
    await fs.writeFile(localPath,Buffer.from(await file.arrayBuffer()));
    fileUrl="/uploads/"+stored;

    try{
      const getSetting=async(key:string)=> (await prisma.setting.findUnique({where:{key}}))?.value;
      const setSetting=async(key:string,value:string)=>{await prisma.setting.upsert({where:{key},update:{value},create:{key,value}})};
      const vs=await getOrCreateVectorStore(level,getSetting,setSetting);
      const indexed=await uploadPdfToVectorStore(localPath,file.name,vs);
      openaiFileId=indexed.id;
    }catch(err){
      console.error("OpenAI indexing failed:",err);
    }
  }

  await prisma.resource.create({data:{title,description,level,type,subjectId:subject.id,fileUrl,openaiFileId}});
  return NextResponse.json({message:openaiFileId?"Ressource ajoutée et indexée pour l'IA.":"Ressource ajoutée. L'indexation IA n'a pas pu être effectuée."});
}
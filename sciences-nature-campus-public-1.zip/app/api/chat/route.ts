import {NextResponse} from "next/server";
import {openai} from "@/lib/openai";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";

export async function POST(req:Request){
  try{
    const {question}=await req.json();
    if(!question?.trim()) return NextResponse.json({error:"Question vide."},{status:400});

    const session=await getSession();
    const user=session?await prisma.user.findUnique({where:{id:session.id}}):null;
    const level=(user?.level==="L2"?"L2":"L1") as "L1"|"L2";
    const setting=await prisma.setting.findUnique({where:{key:`VECTOR_STORE_${level}`}});
    const vectorStoreId=setting?.value;

    const tools:any[]=[];
    if(vectorStoreId) tools.push({type:"file_search",vector_store_ids:[vectorStoreId],max_num_results:8});

    const response=await openai.responses.create({
      model:process.env.OPENAI_MODEL||"gpt-5.6-luna",
      instructions:`Tu es le Professeur IA de Sciences Nature Campus. L'étudiant est en ${level}. Réponds en français et adapte précisément le niveau. Lorsque des documents du campus sont disponibles via la recherche de fichiers, utilise-les en priorité. Cite clairement le titre du document quand tu t'appuies dessus. Si les documents ne permettent pas de répondre, dis-le puis complète avec tes connaissances générales. Pour un exercice, guide étape par étape et vérifie les unités, hypothèses et résultats.`,
      input:question,
      tools
    });

    if(user) await prisma.chatMessage.createMany({data:[
 {userId:user.id,role:"user",content:question,level},
 {userId:user.id,role:"assistant",content:response.output_text,level}
]});
return NextResponse.json({answer:response.output_text,level});
  }catch(e){
    console.error(e);
    return NextResponse.json({error:"Service IA indisponible. Vérifiez la clé API et la configuration OpenAI."},{status:500});
  }
}
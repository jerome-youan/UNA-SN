import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";

export async function GET(){
  const s=await getSession();
  if(!s) return NextResponse.json({error:"Accès interdit."},{status:403});
  const u=await prisma.user.findUnique({where:{id:s.id}});
  if(!u||u.role!=="ADMIN") return NextResponse.json({error:"Accès interdit."},{status:403});

  const resources=await prisma.resource.findMany({
    include:{subject:true},
    orderBy:{createdAt:"desc"}
  });
  return NextResponse.json(resources);
}

import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";
import fs from "fs/promises";
import path from "path";

export async function DELETE(_req:Request,{params}:{params:Promise<{id:string}>}){
  const s=await getSession();
  if(!s) return NextResponse.json({error:"Accès interdit."},{status:403});
  const u=await prisma.user.findUnique({where:{id:s.id}});
  if(!u||u.role!=="ADMIN") return NextResponse.json({error:"Accès interdit."},{status:403});

  const {id}=await params;
  const resource=await prisma.resource.findUnique({where:{id}});
  if(!resource) return NextResponse.json({error:"Ressource introuvable."},{status:404});

  await prisma.resource.delete({where:{id}});

  if(resource.fileUrl?.startsWith("/uploads/")){
    try{
      await fs.unlink(path.join(process.cwd(),"public",resource.fileUrl));
    }catch(err){
      console.error("Impossible de supprimer le fichier local:",err);
    }
  }

  return NextResponse.json({message:"Ressource supprimée. Note : si elle était indexée pour le Professeur IA, pensez à la retirer aussi de la base OpenAI si nécessaire."});
}

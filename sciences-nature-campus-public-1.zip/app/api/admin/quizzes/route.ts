import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";

async function requireAdmin(){
  const s=await getSession();
  if(!s) return null;
  const u=await prisma.user.findUnique({where:{id:s.id}});
  if(!u||u.role!=="ADMIN") return null;
  return u;
}

export async function GET(){
  const admin=await requireAdmin();
  if(!admin) return NextResponse.json({error:"Accès interdit."},{status:403});
  const quizzes=await prisma.quiz.findMany({
    include:{subject:true,questions:true,_count:{select:{attempts:true}}},
    orderBy:{createdAt:"desc"}
  });
  return NextResponse.json(quizzes);
}

export async function POST(req:Request){
  const admin=await requireAdmin();
  if(!admin) return NextResponse.json({error:"Accès interdit."},{status:403});

  const body=await req.json();
  const {title,description,level,subjectId,questions}=body||{};

  if(!title||!subjectId) return NextResponse.json({error:"Titre et matière requis."},{status:400});
  if(level!=="L1"&&level!=="L2") return NextResponse.json({error:"Niveau invalide."},{status:400});
  if(!Array.isArray(questions)||questions.length===0) return NextResponse.json({error:"Ajoutez au moins une question."},{status:400});

  const subject=await prisma.subject.findUnique({where:{id:subjectId}});
  if(!subject||subject.level!==level) return NextResponse.json({error:"Matière invalide pour ce niveau."},{status:400});

  for(const q of questions){
    if(!q.text||!Array.isArray(q.options)||q.options.filter((o:string)=>o&&o.trim()).length<2){
      return NextResponse.json({error:"Chaque question doit avoir un énoncé et au moins 2 options."},{status:400});
    }
    if(typeof q.answerIndex!=="number"||q.answerIndex<0||q.answerIndex>=q.options.length){
      return NextResponse.json({error:"La bonne réponse d'une question est invalide."},{status:400});
    }
  }

  const quiz=await prisma.quiz.create({
    data:{
      title,
      description:description||null,
      level,
      subjectId,
      questions:{create:questions.map((q:any)=>({
        text:q.text,
        options:JSON.stringify(q.options.filter((o:string)=>o&&o.trim())),
        answerIndex:q.answerIndex,
        explanation:q.explanation||null
      }))}
    },
    include:{questions:true}
  });

  return NextResponse.json({message:"Quiz créé.",quiz});
}

import {NextResponse} from "next/server";
import {prisma} from "@/lib/prisma";
import {getSession} from "@/lib/auth";

async function requireAdmin(){
  const s=await getSession();
  if(!s) return null;
  const u=await prisma.user.findUnique({where:{id:s.id}});
  if(!u||u.role!=="ADMIN") return null;
  return u;
}

export async function DELETE(_req:Request,{params}:{params:Promise<{id:string}>}){
  const admin=await requireAdmin();
  if(!admin) return NextResponse.json({error:"Accès interdit."},{status:403});
  const {id}=await params;
  const quiz=await prisma.quiz.findUnique({where:{id}});
  if(!quiz) return NextResponse.json({error:"Quiz introuvable."},{status:404});
  await prisma.quiz.delete({where:{id}});
  return NextResponse.json({message:"Quiz supprimé."});
}
